<!-- markdownlint-disable first-line-h1 -->
In addition to the documentation within this guide, please refer to the following videos for further guidance:

- [Azure Enablement Show](#azure-enablement-show)
  - [Introduction to the Azure landing zones Terraform module](#introduction-to-the-azure-landing-zones-terraform-module)
  - [Start to customize the Azure landing zones Terraform module](#start-to-customize-the-azure-landing-zones-terraform-module)
  - [Advanced customization of the Azure landing zones Terraform module](#advanced-customization-of-the-azure-landing-zones-terraform-module)

## Azure Enablement Show

### Introduction to the Azure landing zones Terraform module

[![Introduction to the Azure landing zones Terraform module](http://img.youtube.com/vi/PqfIeth62Yg/0.jpg)](http://www.youtube.com/watch?v=PqfIeth62Yg "Introduction to the Azure landing zones Terraform module")

### Start to customize the Azure landing zones Terraform module

[![Start to customize the Azure landing zones Terraform module](http://img.youtube.com/vi/vFO_cyolUW0/0.jpg)](http://www.youtube.com/watch?v=vFO_cyolUW0 "Start to customize the Azure landing zones Terraform module")

### Advanced customization of the Azure landing zones Terraform module

[![Advanced customization of the Azure landing zones Terraform module](http://img.youtube.com/vi/ct2KHaA7ekI/0.jpg)](http://www.youtube.com/watch?v=ct2KHaA7ekI "Advanced customization of the Azure landing zones Terraform module")
